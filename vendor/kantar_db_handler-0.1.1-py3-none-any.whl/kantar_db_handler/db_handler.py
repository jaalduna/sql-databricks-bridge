from kantar_db_handler.configs import get_country_params
from kantar_db_handler.sql_alchemy_drv import ConnectionDriver


async def get_df(qry, country):
    params = get_country_params(country)
    server = params["server"]
    database = params["database"]
    return await ConnectionDriver().get_df(qry, server=server, database=database)


async def get_qry(qry, country):
    params = get_country_params(country)
    server = params["server"]
    database = params["database"]
    result = await ConnectionDriver().run_qry(qry, server=server, database=database)
    return result


async def get_stream_df(qry, country, file_name, batch_size=10000):
    params = get_country_params(country)
    server = params["server"]
    database = params["database"]
    await ConnectionDriver().stream_query_to_parquet(
        qry,
        server=server,
        database=database,
        parquet_path=file_name,
        batch_size=batch_size,
    )
