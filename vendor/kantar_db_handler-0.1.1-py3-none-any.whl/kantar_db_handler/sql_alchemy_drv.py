import asyncio
import sqlalchemy.exc
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.sql import text
import pandas as pd
from kantar_db_handler.configs import get_country_params
import pyarrow as pa
import decimal
import pyarrow.parquet as pq
import sys


class DatabaseConnection:
    """A context manager class for handling database connections using SQLAlchemy.

    Attributes:
        server (str): The server name or IP address of the SQL Server.
        database (str): The name of the database to connect to.
        username (str): The username for the database connection.
        password (str): The password for the database connection.
        driver (str): The driver to use for the database connection.
    """

    def __init__(self, server=None, database=None):
        self.server = server
        self.database = database

        self.connection_string = ""
        if server is None:
            print("No server specified")
            return None
        elif database is None:
            print("No database specified")
            self.connection_string = "mssql+aioodbc://{server}/?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server".format(
                server=self.server
            )
        else:
            self.connection_string = "mssql+aioodbc://{server}/{database}?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server".format(
                server=self.server, database=self.database
            )

    async def __aenter__(self):
        self.engine = create_async_engine(self.connection_string, echo=False)
        self.session = AsyncSession(self.engine)
        await self.session.begin()
        return self.session

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if isinstance(self.session, AsyncSession):
            await self.session.close()
            await self.engine.dispose()


class ConnectionDriver:
    def __init__(self):
        pass

    def run_qry_sync(self, *args, **kargs):
        try:
            result = asyncio.run(self.run_qry(*args, **kargs))
            return result
        except Exception as e:
            print("error:", e)

    async def run_qry(self, qry, server=None, database=None):
        async with DatabaseConnection(server, database) as session:
            result = ""
            try:
                result = await session.execute(text(qry))
            except sqlalchemy.exc.ProgrammingError as e:
                print("Problem with driver", e)
                raise Exception
                # return pd.DataFrame()
            except Exception as e:
                print(f"unknown error: {e}")
                raise
            return result

    def get_df_sync(self, *args, **kwargs) -> pd.DataFrame:
        try:
            df = asyncio.run(self.get_df(*args, **kwargs))
            print("ok")
            return df
        except Exception as e:
            print(f"continue execution, this df will be empty {e}")
            return pd.DataFrame()

    async def get_df(self, qry, server=None, database=None, params={}) -> pd.DataFrame:
        async with DatabaseConnection(server, database) as session:
            try:
                result = await session.execute(text(qry), params)
            except sqlalchemy.exc.ProgrammingError as e:
                print("Problem with driver", e)
                raise Exception
                # return pd.DataFrame()
            except Exception as e:
                print(f"unknown error: {e}")
                return
                # return pd.DataFrame().compute()

            data = result.fetchall()
            columns = pd.Index([str(col) for col in result.keys()])
            df = pd.DataFrame(data, columns=columns)
        return df

    async def stream_query_to_parquet(
        self, qry, parquet_path, server=None, database=None, batch_size=10000
    ):
        """
        Streams the result of a query directly to a Parquet file using PyArrow, minimizing memory usage.
        Prints the number of rows read after each batch.
        Applies type conversion for the first chunk and uses the same schema for all batches.
        """

        if server is None or database is None:
            raise ValueError("Server and database must be specified")

        async with DatabaseConnection(server, database) as session:
            result = await session.stream(text(qry))
            columns = list(result.keys())
            first_batch = []
            count = 0
            while count < batch_size:
                row = await result.fetchone()
                if row is None:
                    break
                first_batch.append(tuple(row))
                count += 1

            if not first_batch:
                print("No rows fetched.")
                return

            total_rows = len(first_batch)

            sys.stdout.write(f"Rows read: {total_rows}\r")
            sys.stdout.flush()

            # Type inference and conversion for first batch
            first_batch_dicts = [dict(zip(columns, row)) for row in first_batch]
            arrays = []
            schema_fields = []
            for col in columns:
                col_values = [row[col] for row in first_batch_dicts]
                arr = pa.array(col_values)
                if pa.types.is_integer(arr.type):
                    arr = pa.array(
                        [int(v) if v is not None else None for v in col_values],
                        type=pa.int64(),
                    )
                    schema_fields.append(pa.field(col, pa.int64()))
                elif pa.types.is_decimal(arr.type) or pa.types.is_floating(arr.type):
                    arr = pa.array(
                        [float(v) if v is not None else None for v in col_values],
                        type=pa.float64(),
                    )
                    schema_fields.append(pa.field(col, pa.float64()))
                elif pa.types.is_timestamp(arr.type):
                    arr = pa.array(col_values, type=pa.timestamp("us"))
                    schema_fields.append(pa.field(col, pa.timestamp("us")))
                else:
                    arr = pa.array(col_values)
                    schema_fields.append(pa.field(col, arr.type))
                arrays.append(arr)

            schema = pa.schema(schema_fields)
            table = pa.Table.from_arrays(arrays, schema=schema)
            writer = pq.ParquetWriter(parquet_path, schema)
            writer.write_table(table)

            batch = []
            async for row in result:
                batch.append(tuple(row))
                if len(batch) >= batch_size:
                    batch_dicts = [dict(zip(columns, r)) for r in batch]
                    arrays = []
                    for idx, col in enumerate(columns):
                        col_values = [row[col] for row in batch_dicts]
                        target_type = schema[idx].type

                        if pa.types.is_integer(target_type):
                            arr = pa.array(
                                [int(v) if v is not None else None for v in col_values],
                                type=pa.int64(),
                            )
                        elif pa.types.is_floating(target_type):
                            arr = pa.array(
                                [
                                    float(v) if v is not None else None
                                    for v in col_values
                                ],
                                type=pa.float64(),
                            )
                        elif pa.types.is_timestamp(target_type):
                            arr = pa.array(col_values, type=pa.timestamp("us"))
                        else:
                            arr = pa.array(col_values, type=target_type)
                        arrays.append(arr)
                    table = pa.Table.from_arrays(arrays, schema=schema)
                    writer.write_table(table)
                    total_rows += len(batch)
                    sys.stdout.write(f"Rows read: {total_rows}\r")
                    sys.stdout.flush()

                    batch = []

            # Write any remaining rows
            if batch:
                batch_dicts = [dict(zip(columns, r)) for r in batch]
                arrays = []
                for idx, col in enumerate(columns):
                    col_values = [row[col] for row in batch_dicts]
                    target_type = schema[idx].type
                    if pa.types.is_integer(target_type):
                        arr = pa.array(
                            [int(v) if v is not None else None for v in col_values],
                            type=pa.int64(),
                        )
                    elif pa.types.is_floating(target_type):
                        arr = pa.array(
                            [float(v) if v is not None else None for v in col_values],
                            type=pa.float64(),
                        )
                    elif pa.types.is_timestamp(target_type):
                        arr = pa.array(col_values, type=pa.timestamp("us"))
                    else:
                        arr = pa.array(col_values, type=target_type)
                    arrays.append(arr)
                table = pa.Table.from_arrays(arrays, schema=schema)
                writer.write_table(table)
                total_rows += len(batch)
                sys.stdout.write(f"Rows read: {total_rows}\r")
                sys.stdout.flush()

            print("...done\n ")
            writer.close()


def convert_column(values, target_type):
    # Helper to convert a column to the target type
    if target_type == pa.float64():
        return [float(v) if isinstance(v, decimal.Decimal) else v for v in values]
    elif target_type == pa.int64():
        return [int(v) if v is not None else None for v in values]
    # Add more conversions as needed
    return values
