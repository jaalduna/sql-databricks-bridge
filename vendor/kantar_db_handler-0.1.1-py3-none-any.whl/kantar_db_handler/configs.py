import json
from importlib.resources import files


def get_country_params(country: str):
    """Read config_file and return them as a dict for the given country."""
    try:
        # Use importlib.resources to access the file within the package
        path = files("kantar_db_handler.config_files") / f"{country}.json"

        with path.open("r", encoding="utf-8") as config_file:
            config = json.load(config_file)
    except FileNotFoundError:
        raise Exception(f"Configuration file for '{country}' not found.")
    return config
